﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WorkOrderAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            string userChoice = string.Empty;
            do
            {
                //User menu
                Console.WriteLine("Enter your choice:");
                Console.WriteLine("1 : Add new work order.");
                Console.WriteLine("2 : Delete work order.");
                Console.WriteLine("3 : Add technician.");
                Console.WriteLine("4 : Get all work orders scheduled to a specified date.");
                Console.WriteLine("5 : Get all work orders assigned to a specified technician.");
                Console.WriteLine("6 : Deactivate technician.");
                Console.WriteLine("7 : Assign technician to work order.");
                Console.WriteLine("8 : Quite.");

                userChoice= Console.ReadKey().KeyChar.ToString();

                //Check input and perform opertaion
                switch (userChoice)
                {
                    case "1":
                            ///Add new work order.
                            WorkOrder workOrder = new WorkOrder();
                            Console.WriteLine("Enter reference id.");
                            workOrder.ReferenceId = Console.ReadLine();
                            Console.WriteLine("Enter full postal address.");
                            workOrder.PostalAddress = Console.ReadLine();
                            workOrder.Intervention = DateTime.Now.ToString("MM/dd/yyyy HH:mm");
                            workOrder.RegistrationIdKey = "-1";
                            AddWorkOrder(workOrder);
                            Console.WriteLine("Work order added successfully.");

                        break;

                    case "2":
                        ///Delete work order.
                        Console.WriteLine("Enter the reference for work order to be delete.");
                        string referenceId = Console.ReadLine();
                        DeleteWorkOrder(referenceId);
                        Console.WriteLine("Technician deleted successfully.");

                        break;

                    case "3":
                        ///Add technician.
                        Technician technician = new Technician();
                        Console.WriteLine("Enter first name.");
                        technician.FirstName = Console.ReadLine();
                        Console.WriteLine("Enter last name.");
                        technician.LastName = Console.ReadLine();
                        Console.WriteLine("Enter registration id.");
                        technician.RegistrationId = Console.ReadLine();
                        technician.TechnicianStatus = STATUS.Active.ToString();
                        AddTechnician(technician);
                        Console.WriteLine("Technician added successfully.");

                        break;

                    case "4":
                        ///Get work orders for date
                        Console.WriteLine("Enter the date time to get work orders in the form of <MM/dd/yyyy HH:mm>");
                        string dateTime = Console.ReadLine();
                        List<WorkOrder> workOrdersPerDate = GetWorkOrdersForDate(dateTime);

                        if (null == workOrdersPerDate)
                            Console.WriteLine("No work orders found for givemn intervention date.");
                        else
                        {
                            Console.WriteLine("Reference id\tPostal address\tIntervention\tReeference id");

                            foreach (var workOrderObj in workOrdersPerDate)
                            {
                                Console.WriteLine(workOrderObj.ReferenceId + "\t" + workOrderObj.PostalAddress + "\t" + workOrderObj.Intervention + "\t" + workOrderObj.ReferenceId);
                            }
                        }
                        break;

                    case "5":
                        ///Get work orders for technician
                        Console.WriteLine("Enter the registration id of technician to get work orders assigned.");
                        string registrationID = Console.ReadLine();
                        List<WorkOrder> workOrdersPerTechnician = GetWorkOrdersForTechnician(registrationID);

                        if (null == workOrdersPerTechnician)
                            Console.WriteLine("No work orders found for givemn registration id.");
                        else
                        {
                            Console.WriteLine("Reference id\tPostal address\tIntervention\tReeference id");

                            foreach (var workOrderObj in workOrdersPerTechnician)
                            {
                                Console.WriteLine(workOrderObj.ReferenceId + "\t" + workOrderObj.PostalAddress + "\t" + workOrderObj.Intervention + "\t" + workOrderObj.ReferenceId);
                            }
                        }
                        break;

                    case "6":
                        ///Deactivate technician
                        Console.WriteLine("Enter the registration id of technician to deactivate.");
                        string registrationIDToDeactivate = Console.ReadLine();
                        DeactivateTechnician(registrationIDToDeactivate);

                        break;

                    case "7":
                        ///Assign the technician to work order
                        Console.WriteLine("Enter the reference id of work order which need to be assign.");
                        string referenceIDToAssign = Console.ReadLine();
                        Console.WriteLine("Enter the registration id of technician to assign above work order.");
                        string registrationIDToAssign = Console.ReadLine();
                        AssignTechnicianToWorkOrder(referenceIDToAssign, registrationIDToAssign);

                        break;

                    case "8":
                        ///Quite
                        break;

                    default:
                        Console.WriteLine("Invalid choice, please enter correct choice.");
                        break;
                }

            } while (userChoice != "8");

            Console.WriteLine("Press any key to exit application.");
            Console.ReadKey();
        }

        /// <summary>
        /// Add work order
        /// </summary>
        /// <param name="workOrder">Work order to add</param>
        public static void AddWorkOrder(WorkOrder workOrder)
        {
            using (DataContext data = new DataContext())
            {
                data.WorkOrders.Add(workOrder);
                data.SaveChanges();
            }
        }

        /// <summary>
        /// Delete work order
        /// </summary>
        /// <param name="workOrderReference">Work order to delete</param>
        /// <returns>Trus if success, false otherwise.</returns>
        public static bool DeleteWorkOrder(string workOrderReference)
        {
            bool workOrderDeleted = false;
            try
            {
                using (DataContext data = new DataContext())
                {
                    WorkOrder workOrder = data.WorkOrders.Find(workOrderReference);
                    if (null != workOrder)
                    {
                        data.WorkOrders.Remove(workOrder);
                        data.SaveChanges();
                        workOrderDeleted = true;
                    }
                    else
                        Console.WriteLine("The work order with given reference not found. Please enter correct work order reference and try again.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occured : " + ex.Message);
            }
            return workOrderDeleted;
        }

        /// <summary>
        /// Add technocian
        /// </summary>
        /// <param name="technician">Technician to add.</param>
        public static void AddTechnician(Technician technician)
        {
            using (DataContext data = new DataContext())
            {
                data.Technicians.Add(technician);
                data.SaveChanges();
            }
        }

        /// <summary>
        /// Get work orders per date
        /// </summary>
        /// <param name="dateTime">Date for work orders</param>
        /// <returns>List of work orders.</returns>
        public static List<WorkOrder> GetWorkOrdersForDate(string dateTime)
        {
            List<WorkOrder> workOrders = new List<WorkOrder>();

            try
            {
                using (DataContext data = new DataContext())
                {
                    workOrders = data.WorkOrders.SqlQuery("Select * From WorkOrder where \"Intervention\"=\'" + dateTime + "\'").ToList<WorkOrder>();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error occured : " + ex.Message);
            }

            return workOrders;
        }

        /// <summary>
        /// Get all work orders per technician
        /// </summary>
        /// <param name="registrationNumber">Technician registration id</param>
        /// <returns>List of work orders.</returns>
        public static List<WorkOrder> GetWorkOrdersForTechnician(string registrationNumber)
        {
            List<WorkOrder> workOrders = new List<WorkOrder>();

            try
            {
                using (DataContext data = new DataContext())
                {
                    workOrders = data.WorkOrders.SqlQuery("Select * From WorkOrder where \"RegistrationId\"=\'" + registrationNumber + "\'").ToList<WorkOrder>();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occured : " + ex.Message);
            }

            return workOrders;
        }

        /// <summary>
        /// Deactivate the technician
        /// </summary>
        /// <param name="registrationNumber">Technician registration id to deactivate.</param>
        public static void DeactivateTechnician(string registrationNumber)
        {
            Technician technician = null;

            try
            {
                using (DataContext data = new DataContext())
                {
                    technician = data.Technicians.Find(registrationNumber);
                    if (null != technician)
                    {
                        technician.TechnicianStatus = STATUS.InActive.ToString();
                        data.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occured : " + ex.Message);
            }
        }

        /// <summary>
        /// Assign work order to technician
        /// </summary>
        /// <param name="workOrderReference">Work order reference</param>
        /// <param name="technicianRegistrationNumber">Technician registration id</param>
        public static void AssignTechnicianToWorkOrder(string workOrderReference, string technicianRegistrationNumber)
        {
            Technician technician = null;
            WorkOrder workOrder = null;

            try
            {
                using (DataContext data = new DataContext())
                {
                    technician = data.Technicians.Find(technicianRegistrationNumber);
                    workOrder = data.WorkOrders.Find(workOrderReference);
                    if (null != technician && technician.TechnicianStatus == STATUS.Active.ToString() && null != workOrder)
                    {
                        workOrder.RegistrationIdKey = technicianRegistrationNumber;
                        data.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occured : " + ex.Message);
            }
        }
    }
}
