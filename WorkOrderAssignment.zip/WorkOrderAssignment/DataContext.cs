﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Text;

namespace WorkOrderAssignment
{
    public class DataContext : DbContext
    {        
        public DbSet<WorkOrder> WorkOrders { get; set; }

        public DbSet<Technician> Technicians { get; set; }
    }
}
