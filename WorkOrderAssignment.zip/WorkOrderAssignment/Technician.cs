﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace WorkOrderAssignment
{
    public enum STATUS
    {
        Active, InActive
    }

    [Table(name: "Technician")]
    public class Technician
    {       
        private string registrationId;

        private string firstName;

        private string lastName;

        private string status;

        public virtual ICollection<WorkOrder> WorkOrders { get; set; }

        /// <summary>
        /// Registration ID
        /// </summary>
        [Key]
        [Column(name: "RegistrationId", Order = 0, TypeName = "VARCHAR")]
        public string RegistrationId
        {
            get { return registrationId; }
            set { registrationId = value; }
        }

        /// <summary>
        /// Status of technician
        /// </summary>
        [Column(name: "Status", Order = 3, TypeName = "VARCHAR")]
        public string TechnicianStatus
        {
            get { return status; }
            set { status = value; }
        }


        /// <summary>
        /// Last name
        /// </summary>
        [Column(name: "LastName", Order = 2, TypeName = "VARCHAR")]
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        /// <summary>
        /// First name
        /// </summary>
        [Column(name: "FirstName", Order = 1, TypeName = "VARCHAR")]
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

    }
}
