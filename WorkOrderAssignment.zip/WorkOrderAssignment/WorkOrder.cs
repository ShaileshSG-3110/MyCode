﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace WorkOrderAssignment
{
    [Table(name: "WorkOrder")]
    public class WorkOrder
    {
        private string referenceId;

        private string postalAddress;

        private string intervention;

        private string registrationId;

        [ForeignKey("RegistrationIdKey")]
        public virtual Technician Technician { get; set; }

        /// <summary>
        /// Registration Id
        /// </summary>
        [Column(name: "RegistrationIdKey", Order = 3, TypeName = "VARCHAR")]
        public string RegistrationIdKey
        {
            get { return registrationId; }
            set { registrationId = value; }
        }

        /// <summary>
        /// Intervention date and time
        /// </summary>
        [Column(name: "Intervention", Order = 2, TypeName = "VARCHAR")]
        public string Intervention
        {
            get { return intervention; }
            set { intervention = value; }
        }

        /// <summary>
        /// Full postal address
        /// </summary>

        [Column(name: "PostalAddress", Order = 1, TypeName = "VARCHAR")]
        public string PostalAddress
        {
            get { return postalAddress; }
            set { postalAddress = value; }
        }

        /// <summary>
        /// Reference id of technician
        /// </summary>
        [Key]
        [Column(name: "ReferenceId", Order = 0, TypeName = "VARCHAR")]
        public string ReferenceId
        {
            get { return referenceId; }
            set { referenceId = value; }
        }

    }
}
